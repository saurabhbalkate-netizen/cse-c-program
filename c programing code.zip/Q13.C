#include <stdio.h>
#include <conio.h>

struct employee
{
    char name[30];
    int id;
    float salary;
};

void main()
{
    int i;
    struct employee emp[5] = {
        {"Amit Sharma", 101, 25000.00},
        {"Priya Patel", 102, 30000.50},
        {"Rahul Verma", 103, 28000.75},
        {"Sneha Joshi", 104, 35000.00},
        {"Karan Mehta", 105, 40000.25}
    };

    clrscr();
    printf("Employee Details\n");
    printf("-----------------------------------------\n");
    printf("%-5s %-20s %-10s\n", "ID", "Name", "Salary");
    printf("-----------------------------------------\n");
    for (i = 0; i < 5; i++)
        printf("%-5d %-20s %-10.2f\n", emp[i].id, emp[i].name, emp[i].salary);
    getch();
}
