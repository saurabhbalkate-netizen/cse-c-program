#include <stdio.h>
#include <conio.h>

void main()
{
    int i;

    clrscr();
    printf("Squares of 1 to 5 (except 3):\n");
    for (i = 1; i <= 5; i++)
    {
        if (i == 3)
            continue; /* skip number 3 */
        printf("Square of %d = %d\n", i, i * i);
    }
    getch();
}
