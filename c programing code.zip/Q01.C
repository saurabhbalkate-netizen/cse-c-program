#include <stdio.h>
#include <conio.h>

void main()
{
    char ch;
    int a, b;
    char str[31];

    clrscr();

    printf("Enter a character: ");
    ch = getchar();
    printf("You entered: ");
    putchar(ch);
    printf("\n");
    getchar(); /* consume leftover newline */

    printf("Enter two integers: ");
    scanf("%d %d", &a, &b);
    printf("Sum = %d\n", a + b);
    getchar(); /* consume leftover newline */

    printf("Enter a short sentence (max 30 chars): ");
    gets(str);
    printf("You entered: ");
    puts(str);

    getch();
}
